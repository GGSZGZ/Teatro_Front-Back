para ejecutar el proyecto normal, correr index.html + scripts/API-compra.js o backend/API-compra.js

para correr la aplicación en contenedores realiza el siguiente comando desde la raiz
docker-compose up
a continuación en el navegador ingresa a la url
http://localhost:8080/
para contactos
http://localhost:3000/contact
para los tickets
http://localhost:3000/tickets