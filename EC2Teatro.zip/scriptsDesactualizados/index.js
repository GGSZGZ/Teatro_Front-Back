var about = document.getElementById("about");
      if (about) {
        about.addEventListener("click", function (e) {
          window.location.href = "./desktop-about-us.html";
        });
      }
      
      var contact = document.getElementById("contact");
      if (contact) {
        contact.addEventListener("click", function (e) {
          window.location.href = "./desktop-contactos.html";
        });
      }
      
      var grip = document.getElementById("grip");
      if (grip) {
        grip.addEventListener("click", function (e) {
          window.location.href = "./desktop-obra.html";
        });
      }
      
      var linkContainer13 = document.getElementById("linkContainer13");
      if (linkContainer13) {
        linkContainer13.addEventListener("click", function (e) {
          window.location.href = "./desktop-about-us.html";
        });
      }
      
      var linkContainer14 = document.getElementById("linkContainer14");
      if (linkContainer14) {
        linkContainer14.addEventListener("click", function (e) {
          window.location.href = "./desktop-contactos.html";
        });
      }
      
      var socialMediaIconSquare = document.getElementById("socialMediaIconSquare");
      if (socialMediaIconSquare) {
        socialMediaIconSquare.addEventListener("click", function () {
          window.open("https://www.facebook.com/");
        });
      }
      
      var socialMediaContainer = document.getElementById("socialMediaContainer");
      if (socialMediaContainer) {
        socialMediaContainer.addEventListener("click", function () {
          window.open("https://www.instagram.com/");
        });
      }
      
      var socialMediaIconSquare1 = document.getElementById("socialMediaIconSquare1");
      if (socialMediaIconSquare1) {
        socialMediaIconSquare1.addEventListener("click", function () {
          window.open("https://twitter.com/");
        });
      }
      
      var carrusel = document.getElementById("carrusel");
      if (carrusel) {
        carrusel.addEventListener("click", function (e) {
          window.location.href = "./desktop-obra.html";
        });
      }